// Admin Panel JavaScript
class AdminPanel {
    constructor() {
        this.currentUser = null;
        this.products = [];
        this.appointments = [];
        this.contentFormsPopulated = false; // Flag to prevent duplicate form setup
        this.heroImageManagementSetup = false; // Flag to prevent duplicate hero image management setup
        this.analytics = {
            visitors: [],
            pageViews: [],
            sessions: []
        };
        this.settings = {
            content: {
                hero: {
                    eyebrow: 'Now Trending',
                    title: 'David Walker<br>EyeWear',
                    description: 'Immersive, iconic, and innovative. Book your pair today.',
                    images: []
                },
                announcement: {
                    text: 'Our prices are being updated to reflect GST changes. Chat with us for revised prices.',
                    visible: false
                },
                social: {
                    whatsapp: '917000532010',
                    instagram: '@monicaoptohub',
                    facebook: ''
                },
                brands: ['Ray-Ban', 'Gucci', 'Tom Ford', 'Prada', 'Cartier', 'Johnson & Johnson']
            }
        };
        this.useBackend = false; // Flag to enable/disable backend integration - disabled due to auth issues
        
        this.init();
    }

    init() {
        console.log('=== ADMIN PANEL INITIALIZATION ===');
        console.log('Initial settings before load:', this.settings);
        
        this.setupEventListeners();
        this.checkAuth();
        this.trackVisitor();
        this.initializeImagePreview();
        
        // Load data from backend if available
        console.log('useBackend flag:', this.useBackend);
        if (this.useBackend && window.apiClient) {
            console.log('Using backend data loading');
            this.loadBackendData();
        } else {
            console.log('Using localStorage data loading');
            this.loadData();
        }
        
        console.log('Settings after load:', this.settings);
        console.log('Hero content after load:', this.settings.content?.hero);
        
        // Initialize content management AFTER loading data to preserve saved settings
        // Only update content management if no saved content exists at all
        if (!this.settings.content || !this.settings.content.hero) {
            console.log('No saved content structure found, initializing with defaults');
            this.updateContentManagement();
        } else {
            console.log('Saved content structure found, skipping updateContentManagement');
            console.log('Hero content exists:', this.settings.content.hero);
        }
        
        console.log('Final settings after init:', this.settings);
        console.log('Final hero content after init:', this.settings.content?.hero);
    }

    // Authentication
    async checkAuth() {
        const isLoggedIn = localStorage.getItem('adminLoggedIn') === 'true';
        const loginScreen = document.getElementById('loginScreen');
        const adminDashboard = document.getElementById('adminDashboard');

        if (isLoggedIn) {
            // Verify token is still valid
            if (this.useBackend && window.apiClient) {
                try {
                    await window.apiClient.getProfile();
                    // Token is valid, show dashboard
                    loginScreen.style.display = 'none';
                    adminDashboard.style.display = 'block';
                    this.updateDashboard();
                } catch (error) {
                    console.error('Token validation failed:', error);
                    // Token is invalid, clear auth and show login
                    this.clearAuth();
                    loginScreen.style.display = 'block';
                    adminDashboard.style.display = 'none';
                }
            } else {
                // Local mode, just check localStorage
                loginScreen.style.display = 'none';
                adminDashboard.style.display = 'block';
                this.updateDashboard();
            }
        } else {
            loginScreen.style.display = 'block';
            adminDashboard.style.display = 'none';
        }
    }

    // Clear authentication data
    clearAuth() {
        localStorage.removeItem('adminLoggedIn');
        if (window.apiClient) {
            window.apiClient.setToken(null);
        }
        this.currentUser = null;
    }

    setupEventListeners() {
        // Login form
        document.getElementById('loginForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleLogin();
        });

        // Bulk import button
        document.getElementById('bulkImportBtn').addEventListener('click', () => {
            this.showBulkImportModal();
        });

        // Inventory import button
        const inventoryBtn = document.getElementById('inventoryImportBtn');
        if (inventoryBtn) {
            inventoryBtn.addEventListener('click', () => {
                console.log('Inventory import button clicked');
                this.showInventoryImportModal();
            });
            console.log('Inventory import button event listener attached');
        } else {
            console.error('Inventory import button not found!');
        }

        // Mobile menu toggle
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const mobileNavOverlay = document.getElementById('mobileNavOverlay');
        const adminNav = document.getElementById('adminNav');
        
        if (mobileMenuToggle) {
            mobileMenuToggle.addEventListener('click', () => {
                this.toggleMobileMenu();
            });
        }
        
        if (mobileNavOverlay) {
            mobileNavOverlay.addEventListener('click', () => {
                this.closeMobileMenu();
            });
        }

        // Logout button
        document.getElementById('logoutBtn').addEventListener('click', () => {
            this.handleLogout();
        });

        // Navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = link.dataset.section;
                this.showSection(section);
                this.closeMobileMenu(); // Close mobile menu when navigating
            });
        });

        // Product form
        document.getElementById('addProductBtn').addEventListener('click', () => {
            this.showProductForm();
        });

        document.getElementById('productFormElement').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleProductSubmit();
        });

        // Search and filter
        document.getElementById('searchProducts').addEventListener('input', (e) => {
            this.filterProducts();
        });

        document.getElementById('filterCategory').addEventListener('change', (e) => {
            this.filterProducts();
        });

        // Category tabs
        document.querySelectorAll('.category-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                const category = e.target.dataset.category;
                this.filterByCategory(category);
            });
        });

        // Analytics period
        document.getElementById('analyticsPeriod').addEventListener('change', (e) => {
            this.updateAnalytics();
        });

        // Settings forms
        document.getElementById('adminSettingsForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleAdminSettings();
        });

        document.getElementById('websiteSettingsForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleWebsiteSettings();
        });

        // Appointments
        document.getElementById('appointmentStatus').addEventListener('change', (e) => {
            this.filterAppointments();
        });

        document.getElementById('appointmentType').addEventListener('change', (e) => {
            this.filterAppointments();
        });

        document.getElementById('searchAppointments').addEventListener('input', (e) => {
            this.filterAppointments();
        });

        // Content management forms - will be set up when content section is shown
    }

    async handleLogin() {
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const errorDiv = document.getElementById('loginError');

        try {
            if (this.useBackend && window.apiClient) {
                // Use backend authentication
                const response = await window.apiClient.login(username, password);
                this.currentUser = response.user;
                localStorage.setItem('adminLoggedIn', 'true');
                this.checkAuth();
                errorDiv.style.display = 'none';
                this.showMessage('Login successful!', 'success');
            } else {
                // Fallback to local authentication
                if (username === 'admin' && password === 'admin123') {
                    localStorage.setItem('adminLoggedIn', 'true');
                    this.checkAuth();
                    errorDiv.style.display = 'none';
                } else {
                    errorDiv.textContent = 'Invalid username or password';
                    errorDiv.style.display = 'block';
                }
            }
        } catch (error) {
            console.error('Login error:', error);
            errorDiv.textContent = error.message || 'Login failed';
            errorDiv.style.display = 'block';
        }
    }

    async handleLogout() {
        try {
            if (this.useBackend && window.apiClient) {
                await window.apiClient.logout();
            }
        } catch (error) {
            console.error('Logout error:', error);
        } finally {
            this.clearAuth();
            this.checkAuth();
        }
    }

    showSection(sectionName) {
        // Hide all sections
        document.querySelectorAll('.admin-section').forEach(section => {
            section.classList.remove('active');
        });

        // Remove active class from nav links
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });

        // Show selected section
        document.getElementById(sectionName).classList.add('active');
        document.querySelector(`[data-section="${sectionName}"]`).classList.add('active');

        // Update content based on section
        switch(sectionName) {
            case 'dashboard':
                this.updateDashboard();
                break;
            case 'products':
                this.updateProductsList();
                break;
            case 'appointments':
                this.updateAppointmentsList();
                break;
            case 'analytics':
                this.updateAnalytics();
                break;
            case 'content':
                console.log('Switching to content section');
                // Don't reinitialize content management - it's already done during init
                // Just populate forms if they exist
                this.populateContentForms();
                // Ensure form listeners are set up when switching to content section
                setTimeout(() => {
                    this.setupContentFormListeners();
                }, 100);
                // Ensure hero image management is set up when switching to content section
                setTimeout(() => {
                    this.setupHeroImageManagement();
                }, 200);
                break;
            case 'settings':
                this.updateSettings();
                break;
        }
    }

    // Backend data loading
    async loadBackendData() {
        try {
            console.log('Loading data from backend...');
            
            // Load products
            const productsResponse = await window.apiClient.getProducts();
            this.products = productsResponse.products || [];
            
            // Load appointments
            const appointmentsResponse = await window.apiClient.getAppointments();
            this.appointments = appointmentsResponse.appointments || [];
            
            // Load settings
            this.settings = await window.apiClient.getSettings();
            
            // Load analytics
            const analyticsResponse = await window.apiClient.getAnalyticsStats();
            this.analytics = analyticsResponse;
            
            console.log('Backend data loaded successfully');
            console.log('Products:', this.products.length);
            console.log('Appointments:', this.appointments.length);
            
        } catch (error) {
            console.error('Error loading backend data:', error);
            console.log('Falling back to local data...');
            this.loadData();
        }
    }

    // Dashboard
    updateDashboard() {
        const totalVisitors = this.analytics.visitors.length;
        const totalProducts = this.products.length;
        const todayVisitors = this.getTodayVisitors();
        const featuredProducts = this.products.filter(p => p.featured).length;

        document.getElementById('totalVisitors').textContent = totalVisitors;
        document.getElementById('totalProducts').textContent = totalProducts;
        document.getElementById('todayVisitors').textContent = todayVisitors;
        document.getElementById('featuredProducts').textContent = featuredProducts;

        this.updateRecentActivity();
    }

    updateRecentActivity() {
        const activityList = document.getElementById('recentActivity');
        const activities = this.getRecentActivities();

        if (activities.length === 0) {
            activityList.innerHTML = '<p class="no-data">No recent activity</p>';
            return;
        }

        activityList.innerHTML = activities.map(activity => `
            <div class="activity-item">
                <div class="activity-icon">${activity.icon}</div>
                <div class="activity-content">
                    <p class="activity-text">${activity.text}</p>
                    <p class="activity-time">${activity.time}</p>
                </div>
            </div>
        `).join('');
    }

    getRecentActivities() {
        const activities = [];
        const now = new Date();

        // Add recent product additions
        const recentProducts = this.products
            .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
            .slice(0, 3);

        recentProducts.forEach(product => {
            activities.push({
                icon: '📦',
                text: `Added product: ${product.name}`,
                time: this.formatTimeAgo(new Date(product.createdAt))
            });
        });

        // Add recent visitors
        const recentVisitors = this.analytics.visitors
            .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
            .slice(0, 2);

        recentVisitors.forEach(visitor => {
            activities.push({
                icon: '👤',
                text: `New visitor from ${visitor.location || 'Unknown'}`,
                time: this.formatTimeAgo(new Date(visitor.timestamp))
            });
        });

        return activities.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp)).slice(0, 5);
    }

    // Products
    showProductForm(product = null) {
        const form = document.getElementById('productForm');
        const formTitle = document.getElementById('formTitle');
        const formElement = document.getElementById('productFormElement');

        if (product) {
            formTitle.textContent = 'Edit Product';
            formElement.dataset.productId = product.id;
            this.populateProductForm(product);
        } else {
            formTitle.textContent = 'Add New Product';
            formElement.reset();
            delete formElement.dataset.productId; // Clear the product ID for new products
            this.clearImagePreview();
        }

        form.style.display = 'block';
        form.scrollIntoView({ behavior: 'smooth' });
    }

    hideProductForm() {
        document.getElementById('productForm').style.display = 'none';
    }

    populateProductForm(product) {
        document.getElementById('productName').value = product.name;
        document.getElementById('productBrand').value = product.brand;
        document.getElementById('productPrice').value = product.price;
        document.getElementById('productCategory').value = product.category;
        document.getElementById('productGender').value = product.gender;
        document.getElementById('productModel').value = product.model || '';
        document.getElementById('productDescription').value = product.description || '';
        document.getElementById('productImages').value = '';
        document.getElementById('productFeatured').checked = product.featured || false;
        
        // Clear and populate image preview
        this.clearImagePreview();
        if (product.images && product.images.length > 0) {
            product.images.forEach((image, index) => {
                this.addImageToPreview(image.image_url, index === 0);
            });
        }
    }

    async handleProductSubmit() {
        const formData = new FormData(document.getElementById('productFormElement'));
        
        // Handle multiple images FIRST, before getting other form data
        const imageFiles = document.getElementById('productImages').files;
        console.log('Image files selected:', imageFiles.length);
        if (imageFiles.length > 0) {
            // Clear any existing 'images' entries in FormData
            formData.delete('images');
            for (let i = 0; i < imageFiles.length; i++) {
                console.log(`Adding image ${i} to FormData:`, imageFiles[i].name, imageFiles[i].type, imageFiles[i].size);
                formData.append('images', imageFiles[i]);
            }
        } else {
            console.log('No images selected');
        }
        
        // Log all FormData entries for debugging
        console.log('FormData entries:');
        for (let [key, value] of formData.entries()) {
            if (value instanceof File) {
                console.log(`${key}: File(${value.name}, ${value.type}, ${value.size} bytes)`);
            } else {
                console.log(`${key}: ${value}`);
            }
        }
        
        // Map form field names to backend expected keys
        // Backend expects: name, brand, price, category, gender, model, description, featured
        formData.set('name', formData.get('productName') || '');
        formData.set('brand', formData.get('productBrand') || '');
        formData.set('price', String(parseFloat(formData.get('productPrice') || '')));
        formData.set('category', formData.get('productCategory') || '');
        formData.set('gender', formData.get('productGender') || '');
        formData.set('model', formData.get('productModel') || '');
        formData.set('description', formData.get('productDescription') || '');
        // Checkbox handling: use checked state to send 'true'/'false'
        const featuredChecked = document.getElementById('productFeatured').checked;
        formData.set('featured', featuredChecked ? 'true' : 'false');
        
        const product = {
            name: formData.get('productName'),
            brand: formData.get('productBrand'),
            price: parseFloat(formData.get('productPrice')),
            category: formData.get('productCategory'),
            gender: formData.get('productGender'),
            model: formData.get('productModel'),
            description: formData.get('productDescription'),
            featured: formData.get('productFeatured') === 'on'
        };

        try {
            // Check if editing existing product
            const existingProductId = document.getElementById('productFormElement').dataset.productId;
            console.log('Product form submission - existingProductId:', existingProductId);
            
            if (existingProductId) {
                console.log('Updating existing product with ID:', existingProductId);
                // Update existing product
                if (this.useBackend && window.apiClient) {
                    // Send FormData (with files) directly
                    await window.apiClient.updateProduct(existingProductId, formData);
                } else {
                    const index = this.products.findIndex(p => p.id === existingProductId);
                    if (index !== -1) {
                        product.id = existingProductId;
                        product.createdAt = this.products[index].createdAt;
                        this.products[index] = product;
                        this.saveData();
                    }
                }
            } else {
                console.log('Creating new product');
                // Create new product
                if (this.useBackend && window.apiClient) {
                    // Send FormData (with files) directly
                    const newProduct = await window.apiClient.createProduct(formData);
                    this.products.push(newProduct);
                } else {
                    product.id = Date.now().toString();
                    product.createdAt = new Date().toISOString();
                    product.updatedAt = new Date().toISOString();
                    this.products.push(product);
                    this.saveData();
                }
            }

            this.updateProductsList();
            this.hideProductForm();
            this.showMessage('Product saved successfully!', 'success');
            
            // Refresh brands on the main website
            if (window.brandLoader) {
                window.brandLoader.refreshBrands();
            }
            
            // Notify the main website about the update
            this.notifyWebsiteUpdate();
            
        } catch (error) {
            console.error('Error saving product:', error);
            let errorMessage = 'Error saving product: ' + error.message;
            
            if (error.message.includes('Failed to fetch')) {
                errorMessage = 'Network error: Unable to connect to server. Please check if the backend server is running on http://localhost:3001';
            } else if (error.message.includes('Network error')) {
                errorMessage = error.message;
            }
            
            this.showMessage(errorMessage, 'error');
        }
    }

    // Image preview functionality
    clearImagePreview() {
        const preview = document.getElementById('imagePreview');
        preview.innerHTML = '';
    }

    addImageToPreview(imageUrl, isPrimary = false) {
        const preview = document.getElementById('imagePreview');
        if (!preview) {
            console.error('Image preview container not found');
            return;
        }
        
        const previewItem = document.createElement('div');
        previewItem.className = 'image-preview-item';
        
        const img = document.createElement('img');
        img.src = imageUrl;
        img.alt = 'Product image';
        img.style.width = '100%';
        img.style.height = '100%';
        img.style.objectFit = 'cover';
        
        const removeBtn = document.createElement('button');
        removeBtn.className = 'remove-btn';
        removeBtn.innerHTML = '×';
        removeBtn.onclick = () => {
            previewItem.remove();
        };
        
        previewItem.appendChild(img);
        previewItem.appendChild(removeBtn);
        
        if (isPrimary) {
            const primaryBadge = document.createElement('div');
            primaryBadge.className = 'primary-badge';
            primaryBadge.textContent = 'Primary';
            previewItem.appendChild(primaryBadge);
        }
        
        preview.appendChild(previewItem);
        console.log('Image added to preview:', imageUrl);
    }

    // Initialize image preview functionality
    initializeImagePreview() {
        const fileInput = document.getElementById('productImages');
        if (fileInput) {
            console.log('Image preview initialized');
            fileInput.addEventListener('change', (e) => {
                console.log('File input changed, files:', e.target.files.length);
                this.clearImagePreview();
                const files = Array.from(e.target.files);
                
                files.forEach((file, index) => {
                    console.log(`Processing file ${index}:`, file.name, file.type);
                    if (file.type.startsWith('image/')) {
                        const reader = new FileReader();
                        reader.onload = (e) => {
                            console.log(`Adding image ${index} to preview`);
                            this.addImageToPreview(e.target.result, index === 0);
                        };
                        reader.readAsDataURL(file);
                    } else {
                        console.warn('File is not an image:', file.name);
                    }
                });
            });
        } else {
            console.error('Product images file input not found');
        }
    }

    updateProductsList() {
        const productsList = document.getElementById('productsList');
        const filteredProducts = this.getFilteredProducts();

        // Update category stats
        const activeCategoryTab = document.querySelector('.category-tab.active');
        const activeCategory = activeCategoryTab ? activeCategoryTab.dataset.category : 'all';
        this.updateCategoryStats(activeCategory);

        if (filteredProducts.length === 0) {
            productsList.innerHTML = '<div class="no-data">No products found. Add your first product!</div>';
            return;
        }

        productsList.innerHTML = filteredProducts.map(product => `
            <div class="product-row">
                <div class="table-cell">
                    <img src="${product.image || 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjYwIiBoZWlnaHQ9IjYwIiBmaWxsPSIjRjhGQUZDIi8+CjxwYXRoIGQ9Ik0yMCAyMEg0MFY0MEgyMFYyMFoiIGZpbGw9IiNFMkU4RjAiLz4KPC9zdmc+'}" 
                         alt="${product.name}" 
                         class="product-image" 
                         onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjYwIiBoZWlnaHQ9IjYwIiBmaWxsPSIjRjhGQUZDIi8+CjxwYXRoIGQ9Ik0yMCAyMEg0MFY0MEgyMFYyMFoiIGZpbGw9IiNFMkU4RjAiLz4KPC9zdmc+'">
                </div>
                <div class="table-cell">
                    <p class="product-name">${product.name}</p>
                    <p class="product-brand">${product.brand}</p>
                </div>
                <div class="table-cell">${product.brand}</div>
                <div class="table-cell">${product.category}</div>
                <div class="table-cell product-price">₹${product.price.toLocaleString()}</div>
                <div class="table-cell">
                    ${product.featured ? '<span class="featured-badge">Featured</span>' : '-'}
                </div>
                <div class="table-cell product-actions">
                    <button class="btn btn--small" onclick="adminPanel.editProduct('${product.id}')">Edit</button>
                    <button class="btn btn--small btn--danger" onclick="adminPanel.deleteProduct('${product.id}')">Delete</button>
                </div>
            </div>
        `).join('');
    }

    getFilteredProducts() {
        const searchTerm = document.getElementById('searchProducts').value.toLowerCase();
        const categoryFilter = document.getElementById('filterCategory').value;
        const activeCategoryTab = document.querySelector('.category-tab.active');
        const activeCategory = activeCategoryTab ? activeCategoryTab.dataset.category : 'all';

        return this.products.filter(product => {
            const matchesSearch = product.name.toLowerCase().includes(searchTerm) ||
                                product.brand.toLowerCase().includes(searchTerm) ||
                                (product.model && product.model.toLowerCase().includes(searchTerm));
            const matchesCategory = !categoryFilter || product.category === categoryFilter;
            const matchesActiveCategory = this.matchesActiveCategory(product, activeCategory);
            return matchesSearch && matchesCategory && matchesActiveCategory;
        });
    }

    matchesActiveCategory(product, activeCategory) {
        if (activeCategory === 'all') return true;
        if (activeCategory === 'men') return product.gender === 'men' || product.gender === 'unisex';
        if (activeCategory === 'women') return product.gender === 'women' || product.gender === 'unisex';
        return product.category === activeCategory;
    }

    filterByCategory(category) {
        // Update active tab
        document.querySelectorAll('.category-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        document.querySelector(`[data-category="${category}"]`).classList.add('active');

        // Update category stats
        this.updateCategoryStats(category);

        // Filter products
        this.updateProductsList();
    }

    updateCategoryStats(activeCategory) {
        const stats = this.getCategoryStats(activeCategory);
        document.getElementById('categoryStats').textContent = stats;
    }

    getCategoryStats(activeCategory) {
        const totalProducts = this.products.length;
        let categoryProducts = [];

        if (activeCategory === 'all') {
            categoryProducts = this.products;
        } else if (activeCategory === 'men') {
            categoryProducts = this.products.filter(p => p.gender === 'men' || p.gender === 'unisex');
        } else if (activeCategory === 'women') {
            categoryProducts = this.products.filter(p => p.gender === 'women' || p.gender === 'unisex');
        } else {
            categoryProducts = this.products.filter(p => p.category === activeCategory);
        }

        const categoryCount = categoryProducts.length;
        const featuredCount = categoryProducts.filter(p => p.featured).length;

        if (activeCategory === 'all') {
            return `${totalProducts} total products • ${featuredCount} featured`;
        } else {
            return `${categoryCount} products • ${featuredCount} featured`;
        }
    }

    filterProducts() {
        this.updateProductsList();
    }

    editProduct(productId) {
        const product = this.products.find(p => p.id === productId);
        if (product) {
            this.showProductForm(product);
        }
    }

    async deleteProduct(productId) {
        if (confirm('Are you sure you want to delete this product?')) {
            try {
                if (this.useBackend && window.apiClient) {
                    await window.apiClient.deleteProduct(productId);
                } else {
                    this.products = this.products.filter(p => p.id !== productId);
                    this.saveData();
                }
                
                this.updateProductsList();
                this.showMessage('Product deleted successfully!', 'success');
                
                // Notify the main website about the update
                this.notifyWebsiteUpdate();
                
            } catch (error) {
                console.error('Error deleting product:', error);
                this.showMessage('Error deleting product: ' + error.message, 'error');
            }
        }
    }

    // Notify main website about data updates
    notifyWebsiteUpdate() {
        console.log('notifyWebsiteUpdate called');
        // Save data first
        this.saveData();
        
        // Dispatch custom event for same-page updates
        console.log('Dispatching adminDataUpdated event');
        window.dispatchEvent(new CustomEvent('adminDataUpdated', {
            detail: { products: this.products }
        }));
        
        // Also trigger storage event for cross-tab updates
        console.log('Dispatching storage event');
        window.dispatchEvent(new StorageEvent('storage', {
            key: 'adminPanelData',
            newValue: JSON.stringify(this.getAdminData())
        }));
        
        // Update the main website immediately
        this.updateMainWebsite();
        
        // Refresh hero slider if function exists
        if (typeof window.refreshHeroSlider === 'function') {
            window.refreshHeroSlider();
        }
        
        console.log('Website update notification sent');
    }

    // Get admin data for sharing with main website
    getAdminData() {
        return {
            products: this.products,
            appointments: this.appointments,
            analytics: this.analytics,
            settings: this.settings,
            lastUpdated: new Date().toISOString()
        };
    }

    // Update main website content
    updateMainWebsite() {
        // This will be called when products are updated
        console.log('Updating main website with new data...');
        console.log('Current products count:', this.products.length);
        
        // Force refresh if main website is open
        if (window.productDisplay) {
            console.log('ProductDisplay found, reloading products...');
            window.productDisplay.loadProducts();
            window.productDisplay.displayProductsOnPageLoad();
        } else {
            console.log('ProductDisplay not found, trying to initialize...');
            // Try to initialize ProductDisplay if it doesn't exist
            if (typeof ProductDisplay !== 'undefined') {
                window.productDisplay = new ProductDisplay();
            }
        }
        
        // Also update website content manager
        if (window.websiteContentManager) {
            window.websiteContentManager.loadAdminData();
            window.websiteContentManager.updateWebsiteContent();
        }
    }

    // Appointments
    getInitialAppointments() {
        return [
            {
                id: '1',
                type: 'appointment',
                name: 'Priya Sharma',
                email: 'priya.sharma@email.com',
                phone: '+91-9876543210',
                service: 'Eye Exam & Consultation',
                preferredDate: '2024-01-15',
                preferredTime: '10:00 AM',
                message: 'I need a comprehensive eye exam and would like to explore prescription glasses options.',
                status: 'pending',
                createdAt: new Date().toISOString(),
                source: 'Website Booking Form'
            },
            {
                id: '2',
                type: 'contact',
                name: 'Rajesh Kumar',
                email: 'rajesh.kumar@email.com',
                phone: '+91-8765432109',
                service: 'Product Inquiry',
                preferredDate: null,
                preferredTime: null,
                message: 'I am interested in the Gucci sunglasses collection. Can you provide more information about pricing and availability?',
                status: 'pending',
                createdAt: new Date().toISOString(),
                source: 'Contact Form'
            },
            {
                id: '3',
                type: 'appointment',
                name: 'Anita Mehta',
                email: 'anita.mehta@email.com',
                phone: '+91-7654321098',
                service: 'Contact Lens Fitting',
                preferredDate: '2024-01-18',
                preferredTime: '2:00 PM',
                message: 'I want to switch from glasses to contact lenses. Need professional fitting and consultation.',
                status: 'confirmed',
                createdAt: new Date().toISOString(),
                source: 'Website Booking Form'
            },
            {
                id: '4',
                type: 'contact',
                name: 'Vikram Singh',
                email: 'vikram.singh@email.com',
                phone: '+91-6543210987',
                service: 'General Inquiry',
                preferredDate: null,
                preferredTime: null,
                message: 'Do you offer home delivery for contact lenses? What are your delivery charges?',
                status: 'completed',
                createdAt: new Date().toISOString(),
                source: 'WhatsApp'
            },
            {
                id: '5',
                type: 'appointment',
                name: 'Sneha Patel',
                email: 'sneha.patel@email.com',
                phone: '+91-5432109876',
                service: 'Style Consultation',
                preferredDate: '2024-01-20',
                preferredTime: '11:00 AM',
                message: 'Looking for luxury eyewear for a special occasion. Need style consultation and recommendations.',
                status: 'pending',
                createdAt: new Date().toISOString(),
                source: 'Website Booking Form'
            }
        ];
    }

    updateAppointmentsList() {
        const appointmentsList = document.getElementById('appointmentsList');
        const filteredAppointments = this.getFilteredAppointments();

        // Update appointment stats
        this.updateAppointmentStats();

        if (filteredAppointments.length === 0) {
            appointmentsList.innerHTML = '<div class="no-data">No appointments found matching your criteria.</div>';
            return;
        }

        appointmentsList.innerHTML = filteredAppointments.map(appointment => `
            <div class="appointment-row">
                <div class="table-cell appointment-date">${this.formatDate(appointment.createdAt)}</div>
                <div class="table-cell">
                    <p class="appointment-name">${appointment.name}</p>
                </div>
                <div class="table-cell appointment-contact">
                    <div>${appointment.email}</div>
                    <div>${appointment.phone}</div>
                </div>
                <div class="table-cell appointment-type">${appointment.type}</div>
                <div class="table-cell appointment-service">${appointment.service}</div>
                <div class="table-cell">
                    <span class="status-badge status-${appointment.status}">${appointment.status}</span>
                </div>
                <div class="table-cell appointment-actions">
                    <button class="btn btn--small" onclick="adminPanel.viewAppointment('${appointment.id}')">View</button>
                    <button class="btn btn--small btn--ghost" onclick="adminPanel.updateAppointmentStatus('${appointment.id}')">Update</button>
                </div>
            </div>
        `).join('');
    }

    getFilteredAppointments() {
        const searchTerm = document.getElementById('searchAppointments').value.toLowerCase();
        const statusFilter = document.getElementById('appointmentStatus').value;
        const typeFilter = document.getElementById('appointmentType').value;

        return this.appointments.filter(appointment => {
            const matchesSearch = appointment.name.toLowerCase().includes(searchTerm) ||
                                appointment.email.toLowerCase().includes(searchTerm) ||
                                appointment.phone.includes(searchTerm) ||
                                appointment.message.toLowerCase().includes(searchTerm);
            const matchesStatus = statusFilter === 'all' || appointment.status === statusFilter;
            const matchesType = typeFilter === 'all' || appointment.type === typeFilter;
            return matchesSearch && matchesStatus && matchesType;
        });
    }

    filterAppointments() {
        this.updateAppointmentsList();
    }

    updateAppointmentStats() {
        const totalAppointments = this.appointments.filter(a => a.type === 'appointment').length;
        const pendingAppointments = this.appointments.filter(a => a.status === 'pending').length;
        const confirmedAppointments = this.appointments.filter(a => a.status === 'confirmed').length;
        const totalContacts = this.appointments.filter(a => a.type === 'contact').length;

        document.getElementById('totalAppointments').textContent = totalAppointments;
        document.getElementById('pendingAppointments').textContent = pendingAppointments;
        document.getElementById('confirmedAppointments').textContent = confirmedAppointments;
        document.getElementById('totalContacts').textContent = totalContacts;
    }

    viewAppointment(appointmentId) {
        const appointment = this.appointments.find(a => a.id === appointmentId);
        if (!appointment) return;

        const modal = document.getElementById('appointmentModal');
        const modalTitle = document.getElementById('modalTitle');
        const appointmentDetails = document.getElementById('appointmentDetails');

        modalTitle.textContent = `${appointment.type === 'appointment' ? 'Appointment' : 'Contact'} Details`;

        appointmentDetails.innerHTML = `
            <div class="appointment-details">
                <div class="detail-group">
                    <div class="detail-label">Name</div>
                    <div class="detail-value important">${appointment.name}</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Email</div>
                    <div class="detail-value">${appointment.email}</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Phone</div>
                    <div class="detail-value">${appointment.phone}</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Service Type</div>
                    <div class="detail-value important">${appointment.service}</div>
                </div>
                ${appointment.preferredDate ? `
                <div class="detail-group">
                    <div class="detail-label">Preferred Date</div>
                    <div class="detail-value">${this.formatDate(appointment.preferredDate)}</div>
                </div>
                ` : ''}
                ${appointment.preferredTime ? `
                <div class="detail-group">
                    <div class="detail-label">Preferred Time</div>
                    <div class="detail-value">${appointment.preferredTime}</div>
                </div>
                ` : ''}
                <div class="detail-group">
                    <div class="detail-label">Status</div>
                    <div class="detail-value">
                        <span class="status-badge status-${appointment.status}">${appointment.status}</span>
                    </div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Source</div>
                    <div class="detail-value">${appointment.source}</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Message</div>
                    <div class="detail-value">${appointment.message}</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Submitted</div>
                    <div class="detail-value">${this.formatDateTime(appointment.createdAt)}</div>
                </div>
            </div>
        `;

        modal.style.display = 'flex';
        modal.dataset.appointmentId = appointmentId;
    }

    closeAppointmentModal() {
        document.getElementById('appointmentModal').style.display = 'none';
    }

    updateAppointmentStatus(appointmentId) {
        const appointment = this.appointments.find(a => a.id === appointmentId);
        if (!appointment) return;

        const currentStatus = appointment.status;
        const statusOptions = ['pending', 'confirmed', 'completed', 'cancelled'];
        const currentIndex = statusOptions.indexOf(currentStatus);
        const nextIndex = (currentIndex + 1) % statusOptions.length;
        const newStatus = statusOptions[nextIndex];

        appointment.status = newStatus;
        appointment.updatedAt = new Date().toISOString();

        this.saveData();
        this.updateAppointmentsList();
        this.showMessage(`Appointment status updated to ${newStatus}`, 'success');
    }

    exportAppointments() {
        const appointmentsData = this.appointments.map(appointment => ({
            ...appointment,
            formattedDate: this.formatDateTime(appointment.createdAt)
        }));

        const data = {
            appointments: appointmentsData,
            exportDate: new Date().toISOString(),
            totalCount: appointmentsData.length
        };

        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `appointments-export-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        this.showMessage('Appointments exported successfully!', 'success');
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-IN', {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        });
    }

    formatDateTime(dateString) {
        const date = new Date(dateString);
        return date.toLocaleString('en-IN', {
            day: '2-digit',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    // Analytics
    trackVisitor() {
        const visitor = {
            id: this.generateVisitorId(),
            timestamp: new Date().toISOString(),
            userAgent: navigator.userAgent,
            location: this.getVisitorLocation(),
            referrer: document.referrer,
            page: window.location.pathname
        };

        this.analytics.visitors.push(visitor);
        this.analytics.pageViews.push({
            timestamp: new Date().toISOString(),
            page: window.location.pathname,
            visitorId: visitor.id
        });

        this.saveData();
    }

    generateVisitorId() {
        return 'visitor_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    getVisitorLocation() {
        // In a real application, you would use a geolocation service
        return 'Unknown';
    }

    updateAnalytics() {
        const period = parseInt(document.getElementById('analyticsPeriod').value);
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - period);

        const recentVisitors = this.analytics.visitors.filter(v => new Date(v.timestamp) >= cutoffDate);
        const recentPageViews = this.analytics.pageViews.filter(p => new Date(p.timestamp) >= cutoffDate);

        // Update stats
        document.getElementById('analyticsTotalVisitors').textContent = recentVisitors.length;
        document.getElementById('analyticsUniqueVisitors').textContent = new Set(recentVisitors.map(v => v.id)).size;
        document.getElementById('analyticsPageViews').textContent = recentPageViews.length;
        document.getElementById('analyticsAvgSession').textContent = this.calculateAvgSession(recentVisitors);

        // Update popular pages
        this.updatePopularPages(recentPageViews);

        // Update visitor timeline
        this.updateVisitorTimeline(recentVisitors);

        // Update device stats
        this.updateDeviceStats(recentVisitors);
    }

    calculateAvgSession(visitors) {
        if (visitors.length === 0) return '0m';
        
        // Simple calculation - in reality you'd track actual session durations
        const avgMinutes = Math.round(visitors.length * 2.5); // Assume 2.5 minutes average
        return `${avgMinutes}m`;
    }

    updatePopularPages(pageViews) {
        const pageCounts = {};
        pageViews.forEach(pageView => {
            pageCounts[pageView.page] = (pageCounts[pageView.page] || 0) + 1;
        });

        const popularPages = Object.entries(pageCounts)
            .sort(([,a], [,b]) => b - a)
            .slice(0, 5);

        const container = document.getElementById('popularPages');
        if (popularPages.length === 0) {
            container.innerHTML = '<div class="no-data">No data available</div>';
            return;
        }

        container.innerHTML = popularPages.map(([page, views]) => `
            <div class="page-item">
                <span class="page-name">${page || '/'}</span>
                <span class="page-views">${views} views</span>
            </div>
        `).join('');
    }

    updateVisitorTimeline(visitors) {
        const timeline = {};
        visitors.forEach(visitor => {
            const date = new Date(visitor.timestamp).toDateString();
            timeline[date] = (timeline[date] || 0) + 1;
        });

        const timelineData = Object.entries(timeline)
            .sort(([a], [b]) => new Date(a) - new Date(b))
            .slice(-7); // Last 7 days

        const container = document.getElementById('visitorTimeline');
        if (timelineData.length === 0) {
            container.innerHTML = '<div class="no-data">No data available</div>';
            return;
        }

        container.innerHTML = timelineData.map(([date, count]) => `
            <div class="timeline-item">
                <span class="timeline-date">${new Date(date).toLocaleDateString()}</span>
                <span class="timeline-count">${count} visitors</span>
            </div>
        `).join('');
    }

    updateDeviceStats(visitors) {
        const devices = { mobile: 0, desktop: 0, tablet: 0 };
        
        visitors.forEach(visitor => {
            const userAgent = visitor.userAgent.toLowerCase();
            if (/mobile|android|iphone/.test(userAgent)) {
                devices.mobile++;
            } else if (/tablet|ipad/.test(userAgent)) {
                devices.tablet++;
            } else {
                devices.desktop++;
            }
        });

        const total = devices.mobile + devices.desktop + devices.tablet;
        const container = document.getElementById('deviceStats');
        
        if (total === 0) {
            container.innerHTML = '<div class="no-data">No data available</div>';
            return;
        }

        container.innerHTML = Object.entries(devices).map(([device, count]) => `
            <div class="device-item">
                <span class="device-name">${device.charAt(0).toUpperCase() + device.slice(1)}</span>
                <span class="device-percentage">${Math.round((count / total) * 100)}%</span>
            </div>
        `).join('');
    }

    getTodayVisitors() {
        const today = new Date().toDateString();
        return this.analytics.visitors.filter(v => new Date(v.timestamp).toDateString() === today).length;
    }

    // Content Management
    updateContentManagement() {
        console.log('updateContentManagement called');
        console.log('Current settings before update:', this.settings);
        console.log('Hero content before update:', this.settings.content?.hero);
        
        // Ensure settings structure exists
        if (!this.settings.content) {
            console.log('Creating content structure');
            this.settings.content = {};
        }
        if (!this.settings.content.hero) {
            console.log('Creating hero structure with empty images');
            this.settings.content.hero = {
                eyebrow: 'Now Trending',
                title: 'David Walker<br>EyeWear',
                description: 'Immersive, iconic, and innovative. Book your pair today.',
                images: []
            };
        } else {
            console.log('Hero structure exists, preserving images:', this.settings.content.hero.images?.length || 0);
            // Preserve existing images but ensure structure exists
            if (!this.settings.content.hero.images) {
                console.log('Images array missing, creating empty array');
                this.settings.content.hero.images = [];
            }
            // Only set defaults if fields are truly empty (not just whitespace)
            if (!this.settings.content.hero.eyebrow || this.settings.content.hero.eyebrow.trim() === '') {
                this.settings.content.hero.eyebrow = 'Now Trending';
            }
            if (!this.settings.content.hero.title || this.settings.content.hero.title.trim() === '') {
                this.settings.content.hero.title = 'David Walker<br>EyeWear';
            }
            if (!this.settings.content.hero.description || this.settings.content.hero.description.trim() === '') {
                this.settings.content.hero.description = 'Immersive, iconic, and innovative. Book your pair today.';
            }
        }
        
        console.log('Settings after updateContentManagement:', this.settings);
        console.log('Hero content after update:', this.settings.content?.hero);
        if (!this.settings.content.announcement) {
            this.settings.content.announcement = {
                text: 'Our prices are being updated to reflect GST changes. Chat with us for revised prices.',
                visible: false
            };
        }
        if (!this.settings.content.social) {
            this.settings.content.social = {
                whatsapp: '917000532010',
                instagram: '@monicaoptohub',
                facebook: ''
            };
        }
        if (!this.settings.content.brands) {
            this.settings.content.brands = ['Ray-Ban', 'Gucci', 'Tom Ford', 'Prada', 'Cartier', 'Johnson & Johnson'];
        }

        // Populate form fields when DOM is ready
        setTimeout(() => {
            this.populateContentForms();
        }, 100);
    }

    populateContentForms() {
        console.log('Populating content forms...');
        const contentSection = document.getElementById('content');
        console.log('Content section visible:', contentSection ? contentSection.style.display !== 'none' : 'content section not found');
        
        // Ensure content structure exists
        if (!this.settings.content) {
            console.log('Content structure missing, initializing...');
            this.settings.content = {};
        }
        if (!this.settings.content.hero) {
            console.log('Hero structure missing, initializing...');
            this.settings.content.hero = {
                eyebrow: 'Now Trending',
                title: 'David Walker      EyeWear',
                description: 'Immersive, iconic, and innovative. Book your pair today.',
                images: []
            };
        } else {
            console.log('Hero structure exists, preserving content:', {
                eyebrow: this.settings.content.hero.eyebrow,
                title: this.settings.content.hero.title,
                description: this.settings.content.hero.description,
                images: this.settings.content.hero.images?.length || 0
            });
        }
        if (!this.settings.content.announcement) {
            console.log('Announcement structure missing, initializing...');
            this.settings.content.announcement = {
                text: 'Our prices are being updated to reflect GST changes. Chat with us for revised prices.',
                visible: true
            };
        }
        if (!this.settings.content.social) {
            console.log('Social structure missing, initializing...');
            this.settings.content.social = {
                whatsapp: '917000532010',
                instagram: '@monica_opto_hub',
                facebook: 'monicaoptohub'
            };
        }
        if (!this.settings.content.brands) {
            console.log('Brands structure missing, initializing...');
            this.settings.content.brands = ['Ray-Ban', 'Gucci', 'Tom Ford', 'Prada', 'Cartier', 'Johnson & Johnson'];
        }
        
        // Populate hero content
        const heroEyebrow = document.getElementById('heroEyebrow');
        const heroTitle = document.getElementById('heroTitle');
        const heroDescription = document.getElementById('heroDescription');
        
        if (heroEyebrow) {
            heroEyebrow.value = this.settings.content.hero.eyebrow;
            console.log('Populated heroEyebrow with:', this.settings.content.hero.eyebrow);
        }
        if (heroTitle) {
            heroTitle.value = this.settings.content.hero.title;
            console.log('Populated heroTitle with:', this.settings.content.hero.title);
        }
        if (heroDescription) {
            heroDescription.value = this.settings.content.hero.description;
            console.log('Populated heroDescription with:', this.settings.content.hero.description);
        }

        // Populate announcement
        const announcementText = document.getElementById('announcementText');
        const announcementVisible = document.getElementById('announcementVisible');
        
        if (announcementText) announcementText.value = this.settings.content.announcement.text;
        if (announcementVisible) announcementVisible.checked = this.settings.content.announcement.visible;

        // Populate brands
        this.updateBrandList();

        // Populate social media
        const whatsappNumber = document.getElementById('whatsappNumber');
        const instagramHandle = document.getElementById('instagramHandle');
        const facebookPage = document.getElementById('facebookPage');
        
        if (whatsappNumber) whatsappNumber.value = this.settings.content.social.whatsapp;
        if (instagramHandle) instagramHandle.value = this.settings.content.social.instagram;
        if (facebookPage) facebookPage.value = this.settings.content.social.facebook;

        // Setup form listeners when content section is accessed
        setTimeout(() => {
            this.setupContentFormListeners();
        }, 50);
        
        // Always setup hero image management when content section is accessed
        setTimeout(() => {
            this.setupHeroImageManagement();
        }, 100);
        
        // Always load hero images to refresh display
        this.loadHeroImages();
        
        console.log('Content forms populated successfully');
    }

    updateBrandList() {
        const brandList = document.getElementById('brandList');
        if (!brandList) return;

        brandList.innerHTML = this.settings.content.brands.map(brand => `
            <div class="brand-item">
                <span class="brand-name">${brand}</span>
                <button class="btn btn--small btn--danger" onclick="adminPanel.removeBrand('${brand}')">Remove</button>
            </div>
        `).join('');
    }

    setupHeroImageManagement() {
        console.log('setupHeroImageManagement called');
        
        // Prevent multiple initializations
        if (this.heroImageManagementSetup) {
            console.log('Hero image management already set up, skipping initialization');
            return;
        }
        // Check if elements exist before setting up event listeners
        const uploadBtn = document.getElementById('uploadHeroImagesBtn');
        const fileInput = document.getElementById('heroImageUpload');
        const addUrlBtn = document.getElementById('addImageUrlBtn');
        const cancelUrlBtn = document.getElementById('cancelUrlBtn');
        const addUrlSubmitBtn = document.getElementById('addUrlBtn');

        console.log('Elements found:', {
            uploadBtn: !!uploadBtn,
            fileInput: !!fileInput,
            addUrlBtn: !!addUrlBtn,
            cancelUrlBtn: !!cancelUrlBtn,
            addUrlSubmitBtn: !!addUrlSubmitBtn
        });

        // Test if button is clickable
        if (uploadBtn) {
            console.log('Upload button properties:', {
                disabled: uploadBtn.disabled,
                style: uploadBtn.style.cssText,
                display: window.getComputedStyle(uploadBtn).display,
                visibility: window.getComputedStyle(uploadBtn).visibility,
                pointerEvents: window.getComputedStyle(uploadBtn).pointerEvents
            });
        }

        if (!uploadBtn || !fileInput || !addUrlBtn || !cancelUrlBtn || !addUrlSubmitBtn) {
            console.log('Hero image management elements not found, retrying...');
            // Retry after a short delay
            setTimeout(() => this.setupHeroImageManagement(), 100);
            return;
        }

        // Ensure content structure exists
        if (!this.settings.content) {
            console.log('Content structure missing in setupHeroImageManagement, initializing...');
            this.settings.content = {};
        }
        if (!this.settings.content.hero) {
            console.log('Hero structure missing in setupHeroImageManagement, initializing...');
            this.settings.content.hero = {
                eyebrow: 'Now Trending',
                title: 'David Walker<br>EyeWear',
                description: 'Immersive, iconic, and innovative. Book your pair today.',
                images: []
            };
        }

        // Initialize hero images if not exists (only if no images are saved)
        console.log('setupHeroImageManagement - Current images:', this.settings.content.hero.images);
        if (!this.settings.content.hero.images || this.settings.content.hero.images.length === 0) {
            console.log('No images found, initializing with defaults');
            this.settings.content.hero.images = [
                { url: 'uploads/products/product-1759411026052-46282503.jpg', alt: 'Luxury Eyewear Collection' },
                { url: 'uploads/products/product-1759411026053-100997298.jpg', alt: 'Premium Sunglasses' },
                { url: 'uploads/products/product-1759411026056-235782158.jpg', alt: 'Designer Optical Frames' },
                { url: 'uploads/products/product-1759413338969-428804606.jpg', alt: 'Monica Opto Hub Store' }
            ];
            // Save the default images
            this.saveData();
        } else {
            console.log('Images already exist, preserving them:', this.settings.content.hero.images.length, 'images');
            console.log('Preserved images:', this.settings.content.hero.images);
        }

        // Setup event listeners
        uploadBtn.addEventListener('click', () => {
            console.log('Upload button clicked');
            fileInput.click();
        });

        // Also add a direct click handler for debugging
        uploadBtn.onclick = function() {
            console.log('Direct onclick handler triggered');
        };

        fileInput.addEventListener('change', (e) => {
            console.log('File input changed, files:', e.target.files.length);
            this.handleImageUpload(e.target.files);
        });

        addUrlBtn.addEventListener('click', () => {
            document.getElementById('imageUrlForm').style.display = 'block';
        });

        cancelUrlBtn.addEventListener('click', () => {
            document.getElementById('imageUrlForm').style.display = 'none';
            document.getElementById('newImageUrl').value = '';
            document.getElementById('newImageAlt').value = '';
        });

        addUrlSubmitBtn.addEventListener('click', () => {
            this.addImageFromUrl();
        });
        
        console.log('Hero image management setup completed');
        this.heroImageManagementSetup = true;
    }

    setupContentFormListeners() {
        console.log('Setting up content form listeners...');
        
        // Hero content form
        const heroForm = document.getElementById('heroContentForm');
        console.log('Hero form element:', heroForm);
        if (heroForm) {
            // Remove existing listeners to avoid duplicates
            heroForm.removeEventListener('submit', this.handleHeroContentUpdate);
            heroForm.addEventListener('submit', (e) => {
                e.preventDefault();
                console.log('Hero content form submitted');
                console.log('Form element:', e.target);
                console.log('Form data:', new FormData(e.target));
                this.handleHeroContentUpdate();
            });
            console.log('Hero content form listener attached');
        } else {
            console.log('Hero content form not found');
        }

        // Announcement form
        const announcementForm = document.getElementById('announcementForm');
        if (announcementForm) {
            announcementForm.removeEventListener('submit', this.handleAnnouncementUpdate);
            announcementForm.addEventListener('submit', (e) => {
                e.preventDefault();
                console.log('Announcement form submitted');
                this.handleAnnouncementUpdate();
            });
            console.log('Announcement form listener attached');
        }

        // Add brand form
        const addBrandForm = document.getElementById('addBrandForm');
        if (addBrandForm) {
            addBrandForm.removeEventListener('submit', this.handleAddBrand);
            addBrandForm.addEventListener('submit', (e) => {
                e.preventDefault();
                console.log('Add brand form submitted');
                this.handleAddBrand();
            });
            console.log('Add brand form listener attached');
        }

        // Social media form
        const socialForm = document.getElementById('socialMediaForm');
        if (socialForm) {
            socialForm.removeEventListener('submit', this.handleSocialMediaUpdate);
            socialForm.addEventListener('submit', (e) => {
                e.preventDefault();
                console.log('Social media form submitted');
                this.handleSocialMediaUpdate();
            });
            console.log('Social media form listener attached');
        }

        console.log('Content form listeners setup completed');
    }

    loadHeroImages() {
        console.log('loadHeroImages called');
        const container = document.getElementById('heroImagesContainer');
        const images = this.settings.content.hero.images || [];
        
        console.log('Loading images in admin panel:', images.length, 'images');
        console.log('Images data:', images);

        if (images.length === 0) {
            console.log('No images to display');
            if (container) {
                container.innerHTML = '<div class="empty-hero-images">No images added yet. Upload or add image URLs to get started.</div>';
            }
            return;
        }

        container.innerHTML = images.map((image, index) => {
            // Show a clean identifier instead of the long URL
            const imageIdentifier = image.url.startsWith('data:') ? 
                `Image ${index + 1} (Uploaded)` : 
                image.url.split('/').pop() || `Image ${index + 1}`;
            
            return `
            <div class="hero-image-item" data-index="${index}">
                <img src="${image.url}" alt="${image.alt}" class="hero-image-preview" onerror="this.src='assets/Logo monica.png'">
                <div class="hero-image-info">
                    <div class="hero-image-name">${imageIdentifier}</div>
                    <div class="hero-image-alt">${image.alt}</div>
                    <div class="hero-image-actions">
                        <button class="btn-move-up" onclick="adminPanel.moveImageUp(${index})" ${index === 0 ? 'disabled' : ''}>↑</button>
                        <button class="btn-move-down" onclick="adminPanel.moveImageDown(${index})" ${index === images.length - 1 ? 'disabled' : ''}>↓</button>
                        <button class="btn-remove-image" onclick="adminPanel.removeHeroImage(${index})">Remove</button>
                    </div>
                </div>
            </div>
        `;
        }).join('');
    }

    handleImageUpload(files) {
        console.log('handleImageUpload called with', files.length, 'files');
        
        if (!files || files.length === 0) {
            console.log('No files selected');
            return;
        }

        Array.from(files).forEach((file, index) => {
            console.log(`Processing file ${index + 1}:`, file.name, file.type, file.size);
            
            if (file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    console.log('File read successfully:', file.name);
                    const imageData = {
                        url: e.target.result,
                        alt: file.name.replace(/\.[^/.]+$/, '') // Remove file extension
                    };
                    this.settings.content.hero.images.push(imageData);
                    console.log('Image uploaded, total images now:', this.settings.content.hero.images.length);
                    console.log('Current images array:', this.settings.content.hero.images);
                    this.loadHeroImages();
                    this.saveData();
                    console.log('Data saved after image upload');
                    this.showMessage(`Image "${file.name}" uploaded successfully!`, 'success');
                    this.notifyWebsiteUpdate();
                };
                reader.onerror = (error) => {
                    console.error('Error reading file:', error);
                    this.showMessage(`Error reading file "${file.name}"`, 'error');
                };
                reader.readAsDataURL(file);
            } else {
                console.log('Skipping non-image file:', file.name);
                this.showMessage(`Skipped "${file.name}" - only image files are supported`, 'warning');
            }
        });
    }

    addImageFromUrl() {
        const url = document.getElementById('newImageUrl').value.trim();
        const alt = document.getElementById('newImageAlt').value.trim();

        if (!url) {
            this.showMessage('Please enter an image URL', 'warning');
            return;
        }

        const imageData = {
            url: url,
            alt: alt || 'Hero Image'
        };

        this.settings.content.hero.images.push(imageData);
        this.loadHeroImages();
        this.saveData();
        this.showMessage('Image added successfully!', 'success');
        this.notifyWebsiteUpdate();

        // Clear form and hide
        document.getElementById('newImageUrl').value = '';
        document.getElementById('newImageAlt').value = '';
        document.getElementById('imageUrlForm').style.display = 'none';
    }

    moveImageUp(index) {
        if (index > 0) {
            const images = this.settings.content.hero.images;
            [images[index], images[index - 1]] = [images[index - 1], images[index]];
            this.loadHeroImages();
            this.saveData();
            this.notifyWebsiteUpdate();
        }
    }

    moveImageDown(index) {
        const images = this.settings.content.hero.images;
        if (index < images.length - 1) {
            [images[index], images[index + 1]] = [images[index + 1], images[index]];
            this.loadHeroImages();
            this.saveData();
            this.notifyWebsiteUpdate();
        }
    }

    removeHeroImage(index) {
        if (confirm('Are you sure you want to remove this image?')) {
            this.settings.content.hero.images.splice(index, 1);
            this.loadHeroImages();
            this.saveData();
            this.notifyWebsiteUpdate();
            this.showMessage('Image removed successfully!', 'success');
        }
    }

    handleHeroContentUpdate() {
        console.log('handleHeroContentUpdate called');
        
        const eyebrowElement = document.getElementById('heroEyebrow');
        const titleElement = document.getElementById('heroTitle');
        const descriptionElement = document.getElementById('heroDescription');
        
        console.log('Form elements found:', {
            eyebrow: !!eyebrowElement,
            title: !!titleElement,
            description: !!descriptionElement
        });
        
        if (!eyebrowElement || !titleElement || !descriptionElement) {
            console.error('Hero form elements not found');
            return;
        }
        
        console.log('Reading form values:');
        console.log('Eyebrow value:', eyebrowElement.value);
        console.log('Title value:', titleElement.value);
        console.log('Description value:', descriptionElement.value);
        
        this.settings.content.hero.eyebrow = eyebrowElement.value;
        this.settings.content.hero.title = titleElement.value;
        this.settings.content.hero.description = descriptionElement.value;
        
        console.log('Updated settings with form values:');
        console.log('Settings eyebrow:', this.settings.content.hero.eyebrow);
        console.log('Settings title:', this.settings.content.hero.title);
        console.log('Settings description:', this.settings.content.hero.description);

        console.log('Hero content updated:', {
            eyebrow: this.settings.content.hero.eyebrow,
            title: this.settings.content.hero.title,
            description: this.settings.content.hero.description
        });

        this.saveData();
        this.showMessage('Hero section updated successfully!', 'success');
        this.notifyWebsiteUpdate();
    }

    handleAnnouncementUpdate() {
        this.settings.content.announcement.text = document.getElementById('announcementText').value;
        this.settings.content.announcement.visible = document.getElementById('announcementVisible').checked;

        this.saveData();
        this.showMessage('Announcement updated successfully!', 'success');
        this.notifyWebsiteUpdate();
    }

    handleAddBrand() {
        const newBrand = document.getElementById('newBrandName').value.trim();
        if (!newBrand) return;

        if (this.settings.content.brands.includes(newBrand)) {
            this.showMessage('Brand already exists!', 'error');
            return;
        }

        this.settings.content.brands.push(newBrand);
        this.saveData();
        this.updateBrandList();
        document.getElementById('newBrandName').value = '';
        this.showMessage('Brand added successfully!', 'success');
        this.notifyWebsiteUpdate();
    }

    removeBrand(brandName) {
        if (confirm(`Are you sure you want to remove ${brandName}?`)) {
            this.settings.content.brands = this.settings.content.brands.filter(brand => brand !== brandName);
            this.saveData();
            this.updateBrandList();
            this.showMessage('Brand removed successfully!', 'success');
            this.notifyWebsiteUpdate();
        }
    }

    handleSocialMediaUpdate() {
        this.settings.content.social.whatsapp = document.getElementById('whatsappNumber').value;
        this.settings.content.social.instagram = document.getElementById('instagramHandle').value;
        this.settings.content.social.facebook = document.getElementById('facebookPage').value;

        this.saveData();
        this.showMessage('Social media settings updated successfully!', 'success');
        this.notifyWebsiteUpdate();
    }

    // Settings
    updateSettings() {
        // Populate admin settings
        document.getElementById('adminUsername').value = this.settings.admin.username;

        // Populate website settings
        document.getElementById('siteTitle').value = this.settings.website.title;
        document.getElementById('siteDescription').value = this.settings.website.description;
        document.getElementById('contactPhone').value = this.settings.website.contactPhone;
        document.getElementById('contactEmail').value = this.settings.website.contactEmail;
    }

    handleAdminSettings() {
        const username = document.getElementById('adminUsername').value;
        const password = document.getElementById('adminPassword').value;

        this.settings.admin.username = username;
        if (password) {
            this.settings.admin.password = password;
        }

        this.saveData();
        this.showMessage('Admin settings updated successfully!', 'success');
    }

    handleWebsiteSettings() {
        this.settings.website.title = document.getElementById('siteTitle').value;
        this.settings.website.description = document.getElementById('siteDescription').value;
        this.settings.website.contactPhone = document.getElementById('contactPhone').value;
        this.settings.website.contactEmail = document.getElementById('contactEmail').value;

        this.saveData();
        this.showMessage('Website settings updated successfully!', 'success');
    }

    // Data Management
    deepMerge(target, source) {
        console.log('deepMerge called with:', { target, source });
        const result = { ...target };
        
        for (const key in source) {
            if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key])) {
                // Recursively merge nested objects
                console.log(`Deep merging nested object for key: ${key}`);
                result[key] = this.deepMerge(target[key] || {}, source[key]);
            } else {
                // For arrays and primitives, use source value
                console.log(`Using source value for key: ${key} =`, source[key]);
                result[key] = source[key];
            }
        }
        
        console.log('deepMerge result:', result);
        return result;
    }

    exportData() {
        const data = {
            products: this.products,
            analytics: this.analytics,
            settings: this.settings,
            exportDate: new Date().toISOString()
        };

        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `monica-opto-hub-backup-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        this.showMessage('Data exported successfully!', 'success');
    }

    importData() {
        document.getElementById('importFile').click();
    }

    handleImportFile(event) {
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const data = JSON.parse(e.target.result);
                
                if (data.products) this.products = data.products;
                if (data.analytics) this.analytics = data.analytics;
                if (data.settings) this.settings = data.settings;

                this.saveData();
                this.updateDashboard();
                this.updateProductsList();
                this.updateAnalytics();
                this.updateSettings();

                this.showMessage('Data imported successfully!', 'success');
            } catch (error) {
                this.showMessage('Error importing data: Invalid file format', 'error');
            }
        };
        reader.readAsText(file);
    }

    clearAllData() {
        if (confirm('Are you sure you want to clear all data? This action cannot be undone!')) {
            this.products = [];
            this.analytics = { visitors: [], pageViews: [], sessions: [] };
            this.saveData();
            this.updateDashboard();
            this.updateProductsList();
            this.updateAnalytics();
            this.showMessage('All data cleared successfully!', 'success');
        }
    }

    // Bulk Import Functions
    showBulkImportModal() {
        document.getElementById('bulkImportModal').style.display = 'flex';
        this.setupBulkImportEventListeners();
    }

    hideBulkImportModal() {
        document.getElementById('bulkImportModal').style.display = 'none';
        this.resetBulkImportModal();
    }

    setupBulkImportEventListeners() {
        // Download template button
        document.getElementById('downloadTemplateBtn').onclick = () => this.downloadCSVTemplate();
        
        // Select CSV button
        document.getElementById('selectCSVBtn').onclick = () => {
            document.getElementById('csvFileInput').click();
        };
        
        // Confirm import button
        document.getElementById('confirmImportBtn').onclick = () => this.confirmBulkImport();
    }

    downloadCSVTemplate() {
        const csvContent = `name,brand,price,category,gender,model,description,featured,image_url,image_url_2,image_url_3
Ray-Ban Aviator Classic,Ray-Ban,10990,sunglasses,unisex,RB3025 001/58,Classic aviator sunglasses with crystal green lenses,true,https://example.com/rayban-aviator-1.jpg,https://example.com/rayban-aviator-2.jpg,https://example.com/rayban-aviator-3.jpg
Gucci Oversized Square,Gucci,20700,sunglasses,women,GG0061S 001,Oversized square sunglasses with crystal lenses,true,https://example.com/gucci-square-1.jpg,https://example.com/gucci-square-2.jpg,
Tom Ford Optical Frame,Tom Ford,24500,optical-frames,men,TF5156 001,Premium optical frame with titanium construction,false,https://example.com/tomford-optical-1.jpg,https://example.com/tomford-optical-2.jpg,
Prada Cat Eye Sunglasses,Prada,33700,sunglasses,women,PR 01VS 1AB-1F0,Elegant cat eye sunglasses with gradient lenses,true,https://example.com/prada-cateye-1.jpg,https://example.com/prada-cateye-2.jpg,https://example.com/prada-cateye-3.jpg
Cartier Skyline Optical,Cartier,96500,optical-frames,unisex,CT0046S 001,Luxury optical frame with 18k gold accents,true,https://example.com/cartier-skyline-1.jpg,https://example.com/cartier-skyline-2.jpg,
Acuvue Oasys Contact Lenses,Johnson & Johnson,2500,contact-lenses,unisex,ACUVUE OASYS,Monthly disposable contact lenses for all-day comfort,false,https://example.com/acuvue-oasys-1.jpg,,
Oakley Holbrook,Oakley,12990,sunglasses,men,OO9013-01,Iconic lifestyle sunglasses with Prizm lenses,true,https://example.com/oakley-holbrook-1.jpg,https://example.com/oakley-holbrook-2.jpg,
Versace Medusa Sunglasses,Versace,28900,sunglasses,women,VE4365 001,Signature Medusa logo on temple with crystal lenses,true,https://example.com/versace-medusa-1.jpg,https://example.com/versace-medusa-2.jpg,https://example.com/versace-medusa-3.jpg
Dolce & Gabbana Sicily,Dolce & Gabbana,45600,sunglasses,women,DG3018 001,Luxury cat-eye sunglasses with gold accents,true,https://example.com/dg-sicily-1.jpg,https://example.com/dg-sicily-2.jpg,
Boss Optical Frame,Boss,18900,optical-frames,men,BU1001S 001,Modern rectangular frame with titanium construction,false,https://example.com/boss-optical-1.jpg,https://example.com/boss-optical-2.jpg,`;

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', 'products_template.csv');
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    handleCSVFile(event) {
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const csvText = e.target.result;
                const products = this.parseCSV(csvText);
                this.showCSVPreview(products);
            } catch (error) {
                this.showMessage('Error reading CSV file: ' + error.message, 'error');
            }
        };
        reader.readAsText(file);
    }

    parseCSV(csvText) {
        const lines = csvText.split('\n').filter(line => line.trim());
        const headers = lines[0].split(',').map(h => h.trim());
        const products = [];

        for (let i = 1; i < lines.length; i++) {
            const values = lines[i].split(',').map(v => v.trim());
            if (values.length >= 5) { // At least name, brand, price, category, gender
                const product = {
                    name: values[0] || '',
                    brand: values[1] || '',
                    price: parseFloat(values[2]) || 0,
                    category: values[3] || '',
                    gender: values[4] || '',
                    model: values[5] || '',
                    description: values[6] || '',
                    featured: values[7] === 'true' || values[7] === '1',
                    image_url: values[8] || '',
                    image_url_2: values[9] || '',
                    image_url_3: values[10] || ''
                };
                products.push(product);
            }
        }

        return products;
    }

    showCSVPreview(products) {
        const previewDiv = document.getElementById('csvPreview');
        const previewTable = document.getElementById('previewTable');
        const importSummary = document.getElementById('importSummary');
        
        // Show preview
        previewDiv.style.display = 'block';
        
        // Create table
        const table = document.createElement('table');
        table.innerHTML = `
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Brand</th>
                    <th>Price</th>
                    <th>Category</th>
                    <th>Gender</th>
                    <th>Featured</th>
                    <th>Images</th>
                </tr>
            </thead>
            <tbody>
                ${products.slice(0, 10).map(product => {
                    const imageCount = [product.image_url, product.image_url_2, product.image_url_3].filter(url => url).length;
                    return `
                        <tr>
                            <td>${product.name}</td>
                            <td>${product.brand}</td>
                            <td>₹${product.price.toLocaleString()}</td>
                            <td>${product.category}</td>
                            <td>${product.gender}</td>
                            <td>${product.featured ? 'Yes' : 'No'}</td>
                            <td>${imageCount} image${imageCount !== 1 ? 's' : ''}</td>
                        </tr>
                    `;
                }).join('')}
            </tbody>
        `;
        
        previewTable.innerHTML = '';
        previewTable.appendChild(table);
        
        // Show summary
        importSummary.textContent = `Ready to import ${products.length} products. ${products.length > 10 ? `(Showing first 10 rows)` : ''}`;
        
        // Store products for import
        this.productsToImport = products;
    }

    async confirmBulkImport() {
        if (!this.productsToImport || this.productsToImport.length === 0) {
            this.showMessage('No products to import', 'error');
            return;
        }

        // Show progress
        document.getElementById('csvPreview').style.display = 'none';
        document.getElementById('importProgress').style.display = 'block';
        
        const progressFill = document.getElementById('progressFill');
        const progressText = document.getElementById('progressText');
        
        try {
            if (this.useBackend && window.apiClient) {
                // Use backend API
                const result = await window.apiClient.bulkImportProducts(this.productsToImport);
                
                // Show results
                this.showImportResults(result);
            } else {
                // Fallback to local storage (for demo purposes)
                this.productsToImport.forEach(product => {
                    product.id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
                    product.createdAt = new Date().toISOString();
                    this.products.push(product);
                });
                
                this.saveData();
                this.updateProductsList();
                
                this.showImportResults({
                    message: `Successfully imported ${this.productsToImport.length} products`,
                    results: {
                        success: this.productsToImport.length,
                        failed: 0,
                        errors: []
                    }
                });
            }
        } catch (error) {
            console.error('Bulk import error:', error);
            this.showMessage('Error importing products: ' + error.message, 'error');
        }
    }

    showImportResults(result) {
        document.getElementById('importProgress').style.display = 'none';
        document.getElementById('importResults').style.display = 'block';
        
        const resultsContent = document.getElementById('resultsContent');
        resultsContent.innerHTML = `
            <div class="success">✅ ${result.message}</div>
            <div style="margin-top: 1rem;">
                <p><strong>Successfully imported:</strong> ${result.results.success} products</p>
                <p><strong>Failed:</strong> ${result.results.failed} products</p>
            </div>
            ${result.results.errors.length > 0 ? `
                <div style="margin-top: 1rem;">
                    <strong>Errors:</strong>
                    <ul style="margin-top: 0.5rem;">
                        ${result.results.errors.map(error => `<li class="error">${error}</li>`).join('')}
                    </ul>
                </div>
            ` : ''}
        `;
        
        // Refresh products list
        this.updateProductsList();
        
        // Auto-close modal after 5 seconds
        setTimeout(() => {
            this.hideBulkImportModal();
        }, 5000);
    }

    resetBulkImportModal() {
        document.getElementById('csvPreview').style.display = 'none';
        document.getElementById('importProgress').style.display = 'none';
        document.getElementById('importResults').style.display = 'none';
        document.getElementById('csvFileInput').value = '';
        this.productsToImport = null;
    }

    // Inventory Import Functions
    showInventoryImportModal() {
        console.log('Opening inventory import modal...');
        const modal = document.getElementById('inventoryImportModal');
        if (!modal) {
            console.error('Inventory import modal not found!');
            this.showMessage('Inventory import modal not found. Please refresh the page.', 'error');
            return;
        }
        modal.style.display = 'flex';
        this.setupInventoryImportEventListeners();
        console.log('Inventory import modal opened successfully');
    }

    hideInventoryImportModal() {
        document.getElementById('inventoryImportModal').style.display = 'none';
        this.resetInventoryImportModal();
    }

    setupInventoryImportEventListeners() {
        // Download inventory template button
        document.getElementById('downloadInventoryTemplateBtn').onclick = () => this.downloadInventoryTemplate();
        
        // Select inventory CSV button
        document.getElementById('selectInventoryBtn').onclick = () => {
            document.getElementById('inventoryFileInput').click();
        };
        
        // Confirm inventory import button
        document.getElementById('confirmInventoryImportBtn').onclick = () => this.confirmInventoryImport();
    }

    downloadInventoryTemplate() {
        const csvContent = `SI No,Product,Product Code,Description,Branch Name,Quantity,Pieces Per Box,Total Number Of Pieces,Average Unit Price,Average Tax %,Total Purchase (Rs)
1,Contact Lens,SL59,SOFLENS - BAUSCH & LOMB - -0.50,Monica opto hub 1,1,6,6,1599,0,1599
2,Lens,SYS9,Ecoo - Monica,Monica opto hub 1,1,,,550,0,550
3,Sunglasses,BOSS 1765,Boss sunglass - Boss,Monica opto hub 1,,,,750,0,750
4,Frame,BOSS 1769 J5G,Boss frame - Boss,Monica opto hub 1,,,,20800,0,20800
5,Sunglasses,BOSS 1770,Boss sunglass - Boss,Monica opto hub 1,,,,16600,0,16600
6,Frame,BOSS 1771,Boss frame - Boss,Monica opto hub 1,,,,19800,0,19800
7,Sunglasses,BOSS 1772,Boss sunglass - Boss,Monica opto hub 1,,,,15700,0,15700
8,Contact Lens,ACUVUE OASYS,Monthly disposable contact lenses,Monica opto hub 1,1,6,6,2500,0,2500
9,Sunglasses,RAY-BAN RB3025,Ray-Ban Aviator Classic,Monica opto hub 1,,,,10990,0,10990
10,Frame,GUCCI GG0061S,Gucci Oversized Square,Monica opto hub 1,,,,20700,0,20700`;

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', 'inventory_template.csv');
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    handleInventoryFile(event) {
        console.log('Inventory file selected:', event.target.files[0]);
        const file = event.target.files[0];
        if (!file) {
            console.log('No file selected');
            return;
        }

        console.log('Reading file:', file.name, file.type, file.size);
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                console.log('File read successfully, parsing CSV...');
                const csvText = e.target.result;
                console.log('CSV text length:', csvText.length);
                const inventoryItems = this.parseInventoryCSV(csvText);
                console.log('Parsed inventory items:', inventoryItems.length);
                this.showInventoryPreview(inventoryItems);
            } catch (error) {
                console.error('Error processing inventory file:', error);
                this.showMessage('Error reading inventory CSV file: ' + error.message, 'error');
            }
        };
        reader.onerror = (error) => {
            console.error('File read error:', error);
            this.showMessage('Error reading file: ' + error.message, 'error');
        };
        reader.readAsText(file);
    }

    parseInventoryCSV(csvText) {
        const lines = csvText.split('\n').filter(line => line.trim());
        const headers = lines[0].split(',').map(h => h.trim());
        const inventoryItems = [];

        for (let i = 1; i < lines.length; i++) {
            const values = lines[i].split(',').map(v => v.trim());
            if (values.length >= 5) { // At least SI No, Product, Product Code, Description, Branch Name
                const item = {
                    siNo: values[0] || '',
                    product: values[1] || '',
                    productCode: values[2] || '',
                    description: values[3] || '',
                    branchName: values[4] || '',
                    quantity: values[5] ? parseInt(values[5]) : null,
                    piecesPerBox: values[6] ? parseInt(values[6]) : null,
                    totalPieces: values[7] ? parseInt(values[7]) : null,
                    averageUnitPrice: values[8] ? parseFloat(values[8]) : 0,
                    averageTaxPercent: values[9] ? parseFloat(values[9]) : 0,
                    totalPurchase: values[10] ? parseFloat(values[10]) : 0
                };
                inventoryItems.push(item);
            }
        }

        return inventoryItems;
    }

    showInventoryPreview(inventoryItems) {
        const previewDiv = document.getElementById('inventoryPreview');
        const previewTable = document.getElementById('inventoryPreviewTable');
        const importSummary = document.getElementById('inventoryImportSummary');
        
        // Show preview
        previewDiv.style.display = 'block';
        
        // Create table
        const table = document.createElement('table');
        table.innerHTML = `
            <thead>
                <tr>
                    <th>SI No</th>
                    <th>Product</th>
                    <th>Product Code</th>
                    <th>Description</th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                    <th>Category</th>
                </tr>
            </thead>
            <tbody>
                ${inventoryItems.slice(0, 10).map(item => {
                    const category = this.mapProductTypeToCategory(item.product);
                    return `
                        <tr>
                            <td>${item.siNo}</td>
                            <td>${item.product}</td>
                            <td>${item.productCode}</td>
                            <td>${item.description}</td>
                            <td>${item.quantity || '-'}</td>
                            <td>₹${item.averageUnitPrice.toLocaleString()}</td>
                            <td>${category}</td>
                        </tr>
                    `;
                }).join('')}
            </tbody>
        `;
        
        previewTable.innerHTML = '';
        previewTable.appendChild(table);
        
        // Show summary
        importSummary.textContent = `Ready to import ${inventoryItems.length} inventory items. ${inventoryItems.length > 10 ? `(Showing first 10 rows)` : ''}`;
        
        // Store items for import
        this.inventoryItemsToImport = inventoryItems;
    }

    mapProductTypeToCategory(productType) {
        const type = productType.toLowerCase();
        if (type.includes('sunglass')) return 'sunglasses';
        if (type.includes('frame')) return 'optical-frames';
        if (type.includes('contact') || type.includes('lens')) return 'contact-lenses';
        return 'sunglasses'; // default
    }

    async confirmInventoryImport() {
        if (!this.inventoryItemsToImport || this.inventoryItemsToImport.length === 0) {
            this.showMessage('No inventory items to import', 'error');
            return;
        }

        // Show progress
        document.getElementById('inventoryPreview').style.display = 'none';
        document.getElementById('inventoryImportProgress').style.display = 'block';
        
        const progressFill = document.getElementById('inventoryProgressFill');
        const progressText = document.getElementById('inventoryProgressText');
        
        try {
            if (this.useBackend && window.apiClient) {
                // Use backend API for inventory import
                const result = await window.apiClient.bulkImportInventory(this.inventoryItemsToImport);
                
                // Show results
                this.showInventoryImportResults(result);
            } else {
                // Fallback to local storage (for demo purposes)
                this.inventoryItemsToImport.forEach(item => {
                    const product = this.convertInventoryItemToProduct(item);
                    product.id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
                    product.createdAt = new Date().toISOString();
                    this.products.push(product);
                });
                
                this.saveData();
                this.updateProductsList();
                
                this.showInventoryImportResults({
                    message: `Successfully imported ${this.inventoryItemsToImport.length} inventory items`,
                    results: {
                        success: this.inventoryItemsToImport.length,
                        failed: 0,
                        errors: []
                    }
                });
            }
        } catch (error) {
            console.error('Inventory import error:', error);
            this.showMessage('Error importing inventory: ' + error.message, 'error');
        }
    }

    convertInventoryItemToProduct(item) {
        return {
            name: item.description || `${item.product} ${item.productCode}`,
            brand: this.extractBrandFromDescription(item.description) || 'Unknown',
            price: item.averageUnitPrice,
            category: this.mapProductTypeToCategory(item.product),
            gender: 'unisex', // Default gender
            model: item.productCode,
            description: item.description,
            featured: false,
            // Store inventory-specific data
            inventory: {
                siNo: item.siNo,
                quantity: item.quantity,
                piecesPerBox: item.piecesPerBox,
                totalPieces: item.totalPieces,
                averageTaxPercent: item.averageTaxPercent,
                totalPurchase: item.totalPurchase,
                branchName: item.branchName
            }
        };
    }

    extractBrandFromDescription(description) {
        // Try to extract brand from description
        const commonBrands = ['Boss', 'Ray-Ban', 'Gucci', 'Tom Ford', 'Prada', 'Cartier', 'Versace', 'Dolce & Gabbana', 'Oakley', 'Acuvue'];
        for (const brand of commonBrands) {
            if (description.toLowerCase().includes(brand.toLowerCase())) {
                return brand;
            }
        }
        return null;
    }

    showInventoryImportResults(result) {
        document.getElementById('inventoryImportProgress').style.display = 'none';
        document.getElementById('inventoryImportResults').style.display = 'block';
        
        const resultsContent = document.getElementById('inventoryResultsContent');
        resultsContent.innerHTML = `
            <div class="success">✅ ${result.message}</div>
            <div style="margin-top: 1rem;">
                <p><strong>Successfully imported:</strong> ${result.results.success} items</p>
                <p><strong>Failed:</strong> ${result.results.failed} items</p>
            </div>
            ${result.results.errors.length > 0 ? `
                <div style="margin-top: 1rem;">
                    <strong>Errors:</strong>
                    <ul style="margin-top: 0.5rem;">
                        ${result.results.errors.map(error => `<li class="error">${error}</li>`).join('')}
                    </ul>
                </div>
            ` : ''}
            <div style="margin-top: 1rem; padding: 0.75rem; background: #f0f9ff; border-radius: 6px; border-left: 4px solid #0ea5e9;">
                <strong>📝 Next Steps:</strong>
                <ul style="margin: 0.5rem 0 0 1rem;">
                    <li>Review imported products and update gender categories if needed</li>
                    <li>Add product images for better presentation</li>
                    <li>Set featured products for homepage display</li>
                    <li>Update product descriptions and pricing as needed</li>
                </ul>
            </div>
        `;
        
        // Refresh products list
        this.updateProductsList();
        
        // Auto-close modal after 8 seconds
        setTimeout(() => {
            this.hideInventoryImportModal();
        }, 8000);
    }

    resetInventoryImportModal() {
        document.getElementById('inventoryPreview').style.display = 'none';
        document.getElementById('inventoryImportProgress').style.display = 'none';
        document.getElementById('inventoryImportResults').style.display = 'none';
        document.getElementById('inventoryFileInput').value = '';
        this.inventoryItemsToImport = null;
    }

    // Mobile Menu Functions
    toggleMobileMenu() {
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const mobileNavOverlay = document.getElementById('mobileNavOverlay');
        const adminNav = document.getElementById('adminNav');
        
        if (mobileMenuToggle && mobileNavOverlay && adminNav) {
            const isActive = adminNav.classList.contains('active');
            
            if (isActive) {
                this.closeMobileMenu();
            } else {
                this.openMobileMenu();
            }
        }
    }

    openMobileMenu() {
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const mobileNavOverlay = document.getElementById('mobileNavOverlay');
        const adminNav = document.getElementById('adminNav');
        
        if (mobileMenuToggle && mobileNavOverlay && adminNav) {
            mobileMenuToggle.classList.add('active');
            mobileNavOverlay.classList.add('active');
            adminNav.classList.add('active');
            document.body.style.overflow = 'hidden'; // Prevent background scrolling
        }
    }

    closeMobileMenu() {
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const mobileNavOverlay = document.getElementById('mobileNavOverlay');
        const adminNav = document.getElementById('adminNav');
        
        if (mobileMenuToggle && mobileNavOverlay && adminNav) {
            mobileMenuToggle.classList.remove('active');
            mobileNavOverlay.classList.remove('active');
            adminNav.classList.remove('active');
            document.body.style.overflow = ''; // Restore scrolling
        }
    }

    // Utility Functions
    formatTimeAgo(date) {
        const now = new Date();
        const diffInSeconds = Math.floor((now - date) / 1000);

        if (diffInSeconds < 60) return 'Just now';
        if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} minutes ago`;
        if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} hours ago`;
        return `${Math.floor(diffInSeconds / 86400)} days ago`;
    }

    showMessage(message, type = 'success') {
        // Remove existing messages
        document.querySelectorAll('.message').forEach(msg => msg.remove());

        const messageDiv = document.createElement('div');
        messageDiv.className = `message message--${type}`;
        messageDiv.textContent = message;

        const main = document.querySelector('.admin-main');
        main.insertBefore(messageDiv, main.firstChild);

        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (messageDiv.parentNode) {
                messageDiv.remove();
            }
        }, 5000);
    }

    // Data Persistence
    saveData() {
        const data = {
            products: this.products,
            appointments: this.appointments,
            analytics: this.analytics,
            settings: this.settings
        };
        try {
            const jsonData = JSON.stringify(data);
            console.log('Saving to localStorage:', jsonData);
            localStorage.setItem('adminPanelData', jsonData);
            console.log('Admin data saved successfully:', data);
            console.log('Hero content saved:', this.settings.content?.hero);
            
            // Verify the save by reading it back
            const verifyData = localStorage.getItem('adminPanelData');
            console.log('Verification - data read back:', verifyData);
        } catch (error) {
            console.error('Error saving admin data:', error);
        }
    }

    getInitialProducts() {
        return [
            {
                id: '1',
                name: 'Ray-Ban Aviator Classic',
                brand: 'Ray-Ban',
                price: 10990,
                category: 'sunglasses',
                gender: 'unisex',
                model: 'RB3025 001/58',
                description: 'Classic aviator sunglasses with crystal green lenses',
                image: '', // Use placeholder instead of external URL
                featured: true,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            },
            {
                id: '2',
                name: 'Gucci Oversized Square',
                brand: 'Gucci',
                price: 20700,
                category: 'sunglasses',
                gender: 'women',
                model: 'GG0061S 001',
                description: 'Oversized square sunglasses with crystal lenses',
                image: '', // Use placeholder instead of external URL
                featured: true,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            },
            {
                id: '3',
                name: 'Tom Ford Optical Frame',
                brand: 'Tom Ford',
                price: 24500,
                category: 'optical-frames',
                gender: 'men',
                model: 'TF5156 001',
                description: 'Premium optical frame with titanium construction',
                image: '', // Use placeholder instead of external URL
                featured: false,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            },
            {
                id: '4',
                name: 'Prada Cat Eye Sunglasses',
                brand: 'Prada',
                price: 33700,
                category: 'sunglasses',
                gender: 'women',
                model: 'PR 01VS 1AB-1F0',
                description: 'Elegant cat eye sunglasses with gradient lenses',
                image: '', // Use placeholder instead of external URL
                featured: true,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            },
            {
                id: '5',
                name: 'Cartier Skyline Optical',
                brand: 'Cartier',
                price: 96500,
                category: 'optical-frames',
                gender: 'unisex',
                model: 'CT0046S 001',
                description: 'Luxury optical frame with 18k gold accents',
                image: '', // Use placeholder instead of external URL
                featured: true,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            },
            {
                id: '6',
                name: 'Acuvue Oasys Contact Lenses',
                brand: 'Johnson & Johnson',
                price: 2500,
                category: 'contact-lenses',
                gender: 'unisex',
                model: 'ACUVUE OASYS',
                description: 'Monthly disposable contact lenses for all-day comfort',
                image: '', // Use placeholder instead of external URL
                featured: false,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            }
        ];
    }

    loadData() {
        const savedData = localStorage.getItem('adminPanelData');
        console.log('Raw localStorage data:', savedData);
        if (savedData) {
            try {
                const data = JSON.parse(savedData);
                console.log('Parsed localStorage data:', data);
                if (data.products && data.products.length > 0) {
                    this.products = data.products;
                }
                if (data.appointments && data.appointments.length > 0) {
                    this.appointments = data.appointments;
                }
                if (data.analytics) this.analytics = data.analytics;
                if (data.settings) {
                    console.log('Loading settings from localStorage:', data.settings);
                    console.log('Current settings before merge:', this.settings);
                    // Deep merge settings to preserve nested objects
                    this.settings = this.deepMerge(this.settings, data.settings);
                    console.log('Settings after deep merge:', this.settings);
                    if (this.settings.content && this.settings.content.hero && this.settings.content.hero.images) {
                        console.log('Hero images loaded from localStorage:', this.settings.content.hero.images.length, 'images');
                    }
                }
            } catch (error) {
                console.error('Error loading saved data:', error);
            }
        } else {
            console.log('No saved data found in localStorage');
        }
    }
}

// Global functions for HTML onclick handlers
function testContentPersistence() {
    console.log('=== TESTING CONTENT PERSISTENCE ===');
    
    // Check if adminPanel is available
    if (!window.adminPanel) {
        console.log('❌ adminPanel not available. Make sure the admin panel is loaded.');
        return false;
    }
    
    // Test 1: Check current settings
    console.log('Current settings:', window.adminPanel.settings);
    
    // Test 2: Update hero content
    window.adminPanel.settings.content.hero.eyebrow = 'TEST EYEBROW';
    window.adminPanel.settings.content.hero.title = 'TEST TITLE';
    window.adminPanel.settings.content.hero.description = 'TEST DESCRIPTION';
    
    // Test 3: Save data
    window.adminPanel.saveData();
    
    // Test 4: Clear current settings
    window.adminPanel.settings.content.hero.eyebrow = 'ORIGINAL';
    window.adminPanel.settings.content.hero.title = 'ORIGINAL';
    window.adminPanel.settings.content.hero.description = 'ORIGINAL';
    
    // Test 5: Load data
    window.adminPanel.loadData();
    
    // Test 6: Check if data was restored
    console.log('Settings after load:', window.adminPanel.settings);
    console.log('Hero content after load:', window.adminPanel.settings.content.hero);
    
    if (window.adminPanel.settings.content.hero.eyebrow === 'TEST EYEBROW') {
        console.log('✅ PERSISTENCE TEST PASSED');
        return true;
    } else {
        console.log('❌ PERSISTENCE TEST FAILED');
        return false;
    }
}

// Manual content update test
function testManualContentUpdate() {
    console.log('=== TESTING MANUAL CONTENT UPDATE ===');
    
    if (!window.adminPanel) {
        console.log('❌ adminPanel not available');
        return false;
    }
    
    // Test 1: Update content directly
    console.log('Updating content directly...');
    window.adminPanel.settings.content.hero.eyebrow = 'MANUAL TEST EYEBROW';
    window.adminPanel.settings.content.hero.title = 'MANUAL TEST TITLE';
    window.adminPanel.settings.content.hero.description = 'MANUAL TEST DESCRIPTION';
    
    // Test 2: Save data
    console.log('Saving data...');
    window.adminPanel.saveData();
    
    // Test 3: Check if form fields are updated
    console.log('Checking form fields...');
    const eyebrowField = document.getElementById('heroEyebrow');
    const titleField = document.getElementById('heroTitle');
    const descriptionField = document.getElementById('heroDescription');
    
    console.log('Form field values:');
    console.log('Eyebrow field:', eyebrowField ? eyebrowField.value : 'NOT FOUND');
    console.log('Title field:', titleField ? titleField.value : 'NOT FOUND');
    console.log('Description field:', descriptionField ? descriptionField.value : 'NOT FOUND');
    
    // Test 4: Trigger form population
    console.log('Triggering form population...');
    window.adminPanel.populateContentForms();
    
    // Test 5: Check form fields again
    console.log('Form field values after population:');
    console.log('Eyebrow field:', eyebrowField ? eyebrowField.value : 'NOT FOUND');
    console.log('Title field:', titleField ? titleField.value : 'NOT FOUND');
    console.log('Description field:', descriptionField ? descriptionField.value : 'NOT FOUND');
    
    return true;
}

// Test refresh persistence
function testRefreshPersistence() {
    console.log('=== TESTING REFRESH PERSISTENCE ===');
    
    if (!window.adminPanel) {
        console.log('❌ adminPanel not available');
        return false;
    }
    
    // Test 1: Check current localStorage
    const currentData = localStorage.getItem('adminPanelData');
    console.log('Current localStorage data:', currentData);
    
    // Test 2: Update content and save
    console.log('Updating content...');
    window.adminPanel.settings.content.hero.eyebrow = 'REFRESH TEST EYEBROW';
    window.adminPanel.settings.content.hero.title = 'REFRESH TEST TITLE';
    window.adminPanel.settings.content.hero.description = 'REFRESH TEST DESCRIPTION';
    
    console.log('Saving data...');
    window.adminPanel.saveData();
    
    // Test 3: Verify save
    const savedData = localStorage.getItem('adminPanelData');
    console.log('Data after save:', savedData);
    
    // Test 4: Parse and verify content
    const parsedData = JSON.parse(savedData);
    console.log('Parsed saved data:', parsedData);
    console.log('Hero content in saved data:', parsedData.settings?.content?.hero);
    
    if (parsedData.settings?.content?.hero?.eyebrow === 'REFRESH TEST EYEBROW') {
        console.log('✅ DATA SAVED CORRECTLY');
        console.log('Now refresh the page and check if the data persists');
        return true;
    } else {
        console.log('❌ DATA NOT SAVED CORRECTLY');
        return false;
    }
}

// Expose test functions globally
window.testManualContentUpdate = testManualContentUpdate;
window.testContentPersistence = testContentPersistence;
window.testLocalStorage = testLocalStorage;
window.testRefreshPersistence = testRefreshPersistence;

// Simple localStorage test that doesn't depend on adminPanel
function testLocalStorage() {
    console.log('=== TESTING LOCALSTORAGE DIRECTLY ===');
    
    // Test 1: Save test data
    const testData = {
        test: {
            hero: {
                eyebrow: 'DIRECT TEST EYEBROW',
                title: 'DIRECT TEST TITLE',
                description: 'DIRECT TEST DESCRIPTION'
            }
        }
    };
    
    localStorage.setItem('testData', JSON.stringify(testData));
    console.log('Test data saved:', testData);
    
    // Test 2: Read test data
    const readData = localStorage.getItem('testData');
    console.log('Test data read:', readData);
    
    // Test 3: Parse and verify
    const parsedData = JSON.parse(readData);
    console.log('Parsed data:', parsedData);
    
    if (parsedData.test.hero.eyebrow === 'DIRECT TEST EYEBROW') {
        console.log('✅ LOCALSTORAGE TEST PASSED');
        return true;
    } else {
        console.log('❌ LOCALSTORAGE TEST FAILED');
        return false;
    }
}

function showSection(sectionName) {
    adminPanel.showSection(sectionName);
}

function hideProductForm() {
    adminPanel.hideProductForm();
}

function exportData() {
    adminPanel.exportData();
}

function importData() {
    adminPanel.importData();
}

function handleImportFile(event) {
    adminPanel.handleImportFile(event);
}

function clearAllData() {
    adminPanel.clearAllData();
}

function exportAppointments() {
    adminPanel.exportAppointments();
}

function closeAppointmentModal() {
    adminPanel.closeAppointmentModal();
}

// Bulk import functions
function hideBulkImportModal() {
    adminPanel.hideBulkImportModal();
}

function handleCSVFile(event) {
    adminPanel.handleCSVFile(event);
}

function hideInventoryImportModal() {
    adminPanel.hideInventoryImportModal();
}

function handleInventoryFile(event) {
    adminPanel.handleInventoryFile(event);
}

// Initialize admin panel when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.adminPanel = new AdminPanel();
});
